package ru.geekbrains.corelib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreLibApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoreLibApplication.class, args);
    }

}
