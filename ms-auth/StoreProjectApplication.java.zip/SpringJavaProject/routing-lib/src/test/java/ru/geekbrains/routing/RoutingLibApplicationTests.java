package ru.geekbrains.routing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoutingLibApplicationTests {

    @Test
    void contextLoads() {
    }

}
