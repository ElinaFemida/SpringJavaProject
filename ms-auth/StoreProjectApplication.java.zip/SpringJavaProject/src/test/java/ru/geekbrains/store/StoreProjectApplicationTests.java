package ru.geekbrains.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
