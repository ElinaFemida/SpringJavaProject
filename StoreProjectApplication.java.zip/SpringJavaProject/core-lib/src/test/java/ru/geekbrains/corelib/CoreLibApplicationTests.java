package ru.geekbrains.corelib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreLibApplicationTests {

    @Test
    void contextLoads() {
    }

}
