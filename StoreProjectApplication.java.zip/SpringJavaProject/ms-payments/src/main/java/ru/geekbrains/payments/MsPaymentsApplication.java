package ru.geekbrains.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsPaymentsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsPaymentsApplication.class, args);
    }

}
